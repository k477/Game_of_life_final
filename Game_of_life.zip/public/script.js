side = 10;
matrixSize = 80;
const socket = io.connect('http://localhost:3000')

function setup() {
    // createCanvas(matrix[0].length * side, matrix.length * side);
    createCanvas(800, 800);
    background('grey');
    frameRate(4);
    noStroke();
}

function drawMatrix(matrix) {
    for (let y = 0; y < matrix.length; y++) {
        const element = matrix[y];
        for (let x = 0; x < element.length; x++) {

            if (matrix[y][x] == 1) {
                fill('green');
            }
            else if (matrix[y][x] == 2) {
                fill('yellow');
            }
            else if (matrix[y][x] == 3) {
                fill('red');
            }
            else if (matrix[y][x] == 4) {
                fill('pink');
            }
            else if (matrix[y][x] == 5) {
                fill('#B404AE');
            }
            else if (matrix[y][x] == 6) {
                fill('brown');
            }
            else if (matrix[y][x] == 7) {
                fill('white');
            }
            else {
                fill('grey');
            }
            ellipse(x * side, y * side, side, side);
        }
    }
}

socket.on("sending_matrix", function (matrix) {
    drawMatrix(matrix);
});
socket.on("sending_weather", function (currentWeather) {
    document.getElementById("current-weather").innerHTML = `It is ${currentWeather}`;
});

document.getElementById("creator").addEventListener("click", () => {
    socket.emit('call_creator', matrix => {
        drawMatrix(matrix);
    });
});

document.getElementById("virus").addEventListener("click", () => {
    socket.emit('call_virus', matrix => {
        drawMatrix(matrix);
    });
});

