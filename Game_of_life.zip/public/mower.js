var Creature = require('./creature');
module.exports = class Mower extends Creature {
    constructor(x, y) {
        super(x, y);
        this.energy = 100;
    }
    die() {
        matrix[this.y][this.x] = 0;
        for (let index = 0; index < mowerArr.length; index++) {
            if (mowerArr[index].x == this.x && mowerArr[index].y == this.y) {
                mowerArr.splice(index, 1)
            }
        }
    }

    move() {
        this.energy -= 5;
        var cells = this.chooseCell(0);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 6;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;
        }

        var cells = this.chooseCell(1);
        newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 6;
            matrix[this.y][this.x] = 1;

            this.y = y;
            this.x = x;
        }

        if (this.energy < 1) {
            this.die();
        }
    }


    mul() {
        var cells = this.chooseCell(0);
        if (cells.length) {
            let newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell) {
                let x = newCell[0];
                let y = newCell[1];
                matrix[y][x] = 6;
                let mower = new Mower(x, y);
                mowerArr.push(mower);
                this.energy = 0;
            }
        }
    }
    getNewDirections() {
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1]
        ];

    }

    mow() {
        this.getNewDirections();
        var cells = this.chooseCell(1);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];

            matrix[y][x] = 6;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;

            for (let index = 0; index < grassArr.length; index++) {
                if (grassArr[index].x == x && grassArr[index].y == y) {
                    grassArr.splice(index, 1)
                }
            }
            
            cells = this.chooseCell(5);
            newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell) {
                this.mul()
            }
        }
        else { this.move() }
    }

}