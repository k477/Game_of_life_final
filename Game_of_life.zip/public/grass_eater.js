var Creature = require('./creature');
module.exports = class GrassEater extends Creature {
    constructor(x, y) {
        super(x, y);
        this.energy = 30;
    }
    mul() {
        var cells = this.chooseCell(0);
        if (cells.length) {
            let newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell) {
                let x = newCell[0];
                let y = newCell[1];
                matrix[y][x] = 2;
                let grassEater = new GrassEater(x, y);
                grassEaterArr.push(grassEater);
                this.energy = 0;
            }
        }
    }
    getNewDirections() {
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1]
        ];

    }

    die() {
        matrix[this.y][this.x] = 0;
        for (let index = 0; index < grassEaterArr.length; index++) {
            if (grassEaterArr[index].x == this.x && grassEaterArr[index].y == this.y) {
                grassEaterArr.splice(index, 1);
                
            }
        }
    }
    eat() {
        this.getNewDirections();
        var cells = this.chooseCell(1);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            this.energy += 5;
            let x = newCell[0];
            let y = newCell[1];

            matrix[y][x] = 2;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;

            for (let index = 0; index < grassArr.length; index++) {
                if (grassArr[index].x == x && grassArr[index].y == y) {
                    grassArr.splice(index, 1)
                }
            }

            if (this.energy > 30) {
                this.mul()
            }
        }
        else { this.move() }
    }
    move() {
        this.energy--;
        var cells = this.chooseCell(0);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 2;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;
        }
        if (newCell && this.energy < 0) {
            this.die();
        }
        if (this.energy < 0) {
            this.die();
        }
    }
}