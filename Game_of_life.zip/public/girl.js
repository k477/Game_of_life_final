var Creature = require('./creature');
module.exports = class Girl extends Creature {
    constructor(x, y) {
        super(x, y);
        this.energy = 100;
    }
    die() {
        matrix[this.y][this.x] = 0;
        for (let index = 0; index < girlArr.length; index++) {
            if (girlArr[index].x == this.x && girlArr[index].y == this.y) {
                girlArr.splice(index, 1)
            }
        }
    }

    move() {
        this.energy -= 5;
        var cells = this.chooseCell(0);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 5;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;
        }

        var cells = this.chooseCell(1);
        newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 5;
            matrix[this.y][this.x] = 1;

            this.y = y;
            this.x = x;
        }

        if (this.energy < 1) {
            this.die();
        }
    }



    mul() {
        var cells = this.chooseCell(0);
        if (cells.length) {
            let newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell) {
                let x = newCell[0];
                let y = newCell[1];
                matrix[y][x] = 5;
                let girl = new Girl(x, y);
                girlArr.push(girl);
                this.energy = 0;
            }
        }
    }
    getNewDirections() {
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1]
        ];

    }

    pick() {
        this.getNewDirections();
        var cells = this.chooseCell(4);
        let newCell = cells[Math.floor(Math.random() * cells.length)];
        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];

            matrix[y][x] = 5;
            matrix[this.y][this.x] = 0;

            this.y = y;
            this.x = x;

            for (let index = 0; index < flowerArr.length; index++) {
                if (flowerArr[index].x == x && flowerArr[index].y == y) {
                    flowerArr.splice(index, 1)
                }
            }
            cells = this.chooseCell(6);
            newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell) {
                this.mul()
            }
        }
        else { this.move() }
    }



}