var Creature = require('./creature');
module.exports = class Grass extends Creature {
    constructor(x, y) {
        super(x, y);
        this.life = 0;
    }

    mul() {
        this.life += 3;
        var cells = this.chooseCell(0);
        if(cells.length) {
            let newCell = cells[Math.floor(Math.random() * cells.length)];
            if (newCell && this.life > 10) {
                let x = newCell[0];
                let y = newCell[1];
                matrix[y][x] = 1;
                let grass = new Grass(x, y);
                grassArr.push(grass);
                this.life = 0;
            }
        }
       
    }
}